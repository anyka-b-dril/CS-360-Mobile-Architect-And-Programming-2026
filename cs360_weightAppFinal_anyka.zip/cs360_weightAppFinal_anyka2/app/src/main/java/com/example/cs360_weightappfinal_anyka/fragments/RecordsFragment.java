package com.example.cs360_weightappfinal_anyka.fragments;

import static java.security.AccessController.getContext;

import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.helper.widget.Grid;
import androidx.fragment.app.Fragment;

import com.example.cs360_weightappfinal_anyka.DBHelper;
import com.example.cs360_weightappfinal_anyka.GridAdapter;
import com.example.cs360_weightappfinal_anyka.R;
import com.example.cs360_weightappfinal_anyka.WeightRecord;

import java.util.ArrayList;
import java.util.List;

public class RecordsFragment extends Fragment {

    GridView gridView;
    DBHelper dbHelper;
    ImageButton addButton;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_records, container, false);

        gridView = view.findViewById(R.id.gridView);
        dbHelper = DBHelper.getInstance(getContext());
        addButton = view.findViewById(R.id.addButton);

        // Get user
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        // If no user currently active, log as guest
        String username = sharedPreferences.getString("current_username", "Guest");

        // Get all weight records
        Log.d("DB_QUERY", "Searching weight for user: " + username);
        List<WeightRecord> history = dbHelper.getWeightHistory(username);

        /// Send to adapter
        GridAdapter adapter = new GridAdapter(getContext(), history);
        gridView.setAdapter(adapter);

        // If gridview tile is selected
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get selected item at position
                WeightRecord selectedRecord = (WeightRecord) parent.getItemAtPosition(position);
                showEditDialog(selectedRecord);
            }
        });

        Dialog dialog = new Dialog(getContext());

        /*
            Add record
         */
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.setContentView(R.layout.dialog_weight);
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                // When save button is clicked, update the database and dismiss
                Button buttonSave = dialog.findViewById(R.id.saveAddRecord);

                buttonSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Add record to the database
                        EditText inputWeight = dialog.findViewById(R.id.newWeight);
                        String newWeight = inputWeight.getText().toString();
                        // Validate user input
                        try {
                            double newWeightRecord = Double.parseDouble(newWeight);
                            if (dbHelper.insertWeight(username, newWeightRecord)) {
                                Log.d("DB_SAVE", "Saving weight for user: " + username);
                                // Show user success
                                Toast.makeText(getContext(), "Record added", Toast.LENGTH_SHORT).show();
                                // Check for goal match
                                double goal = dbHelper.getGoalWeight(username);
                                // Check SMS
                                boolean canSendSms = sharedPreferences.getBoolean("sms_enabled", false);
                                // If canSendSMS, send SMS notification; else display toast
                                if (canSendSms) {
                                    dbHelper.checkAndSendGoalSMS(getContext(), username, newWeightRecord, goal);
                                }
                                else {
                                    dbHelper.checkGoal(getContext(), newWeightRecord, goal);
                                }
                                // Refresh page
                                refreshGridView();
                            }
                            else {
                                // Show error
                                Toast.makeText(getContext(), "Action failed. Try again.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (NumberFormatException e) {
                            // Show error
                            Toast.makeText(getContext(), "Please enter a number (eg. 100.00)", Toast.LENGTH_SHORT).show();
                        }
                        // Close the dialog box
                        dialog.dismiss();
                    }
                });

                // When cancel button is clicked, dismiss the dialog
                Button buttonCancel = dialog.findViewById(R.id.cancelAddRecord);
                buttonCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Close the dialog box
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh the data every time the fragment becomes visible
        refreshGridView();
    }

    private void refreshGridView() {
        if (dbHelper != null && gridView != null) {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
            String username = sharedPreferences.getString("current_username", "Guest");

            // Fetch the fresh list from DB
            List<WeightRecord> history = dbHelper.getWeightHistory(username);
            Log.d("RECORDS_DEBUG", "Items found in DB: " + history.size());

            // Create and set the new adapter
            GridAdapter adapter = new GridAdapter(getContext(), history);
            gridView.setAdapter(adapter);
        }
    }

    private void showEditDialog(WeightRecord record) {
        // Initialize dialog
        Dialog dialog = new Dialog(getContext());
        // Open dialog
        dialog.setContentView(R.layout.dialog_edit_record);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        // populate variables
        TextView dateText = dialog.findViewById(R.id.dateText);
        TextView currRecord = dialog.findViewById(R.id.weightRecord);
        EditText inputWeight = dialog.findViewById(R.id.newWeight);

        Button buttonDelete = dialog.findViewById(R.id.deleteRecord);
        Button buttonCancel = dialog.findViewById(R.id.cancelUpdateRecord);
        Button buttonSave = dialog.findViewById(R.id.saveUpdateRecord);

        // Get user
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        // If no user currently active, log as guest
        String username = sharedPreferences.getString("current_username", "Guest");

        // Populate the dialog with existing data
        dateText.setText("Edit Entry: " + record.getDate());
        currRecord.setText(String.valueOf(record.getWeight()));

        // Update entry when save is pressed
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add record to the database
                EditText inputWeight = dialog.findViewById(R.id.newWeight);
                String newWeight = inputWeight.getText().toString();
                // Validate user input
                try {
                    double newWeightRecord = Double.parseDouble(newWeight);
                    if (dbHelper.updateWeightEntry(record.getID(), newWeightRecord)) {
                        // Show user success
                        Toast.makeText(getContext(), "Updated!!!", Toast.LENGTH_SHORT).show();
                        // Refresh Grid
                        refreshGridView();
                    }
                    else {
                        // Show error
                        Toast.makeText(getContext(), "Action failed. Try again.", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (NumberFormatException e) {
                    // Show error
                    Toast.makeText(getContext(), "Please enter a number (eg. 100.00)", Toast.LENGTH_SHORT).show();
                }
                // Close the dialog box
                dialog.dismiss();
            }
        });

        // Delete entry when delete is pressed
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dbHelper.deleteWeightEntry(record.getID())) {
                    // Show user success
                    Toast.makeText(getContext(), "Record deleted.", Toast.LENGTH_SHORT).show();
                    // Refresh Grid
                    refreshGridView();
                }
                else {
                    // Show error
                    Toast.makeText(getContext(), "Action failed. Try again.", Toast.LENGTH_SHORT).show();
                }
                // Close the dialog box
                dialog.dismiss();
            }
        });

        // When cancel button is clicked, dismiss the dialog
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close the dialog box
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}

